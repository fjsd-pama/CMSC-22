import java.io.Serializable;

public class Course implements Serializable{
	private String courseCode;
	private String courseDescription;

	public Course( String courseCode, String courseDescription ){
		setCourseCode(courseCode);
		setCourseDescription(courseDescription);
	}

	public void setCourseCode( String courseCode ){
		this.courseCode = courseCode;

	}

	public void setCourseDescription( String courseDescription ){
		this.courseDescription = courseDescription;
		
	}

	public String getCourseCode( String courseCode ){
		return courseCode;

	}

	public String getCourseDescription( String courseCode ){
		return courseDescription;
		
	}

	public String toString() {
        return "Course code: " + courseCode + "\n" +
               "Course description: " + courseDescription;
    }
}